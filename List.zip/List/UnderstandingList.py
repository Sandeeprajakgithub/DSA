# ordered 
#mutable 
# index-based

# How to create list
a = []
print(a)

b = [1,5,3,4,2]
print(b)

c = ["ram","bablu","Pinki"]
print(c)


d = ["ram",23,"Pinki",-1,1.0]
print(d)

# Constructor 
e = list()
print(e)

f = list(("ram","sita","bablu","chandu"))
print(f)

#Repeated Elements 
g = [1,4]*10
print(g)


# Representation of List
# 0 based indexing 
h = ["1","Ram","Sita","lakshman ji","Hanuman ji"]
# i-1
# index-based - Reverse indexing 
print("+++++++++++++++++++++++++")
print(h)
print(h[4])
print(h[0])

print(len(h))
# 3-5 = -2
# negative indexing 
print(h[-1])
print(h[-5])


# What is mutability 
# How to add a entry or data inside list

a = [1,3,4,5,7]
b = list((a))
print(b)

# append 
b.append(8)
print(b)

# insert
a = [1,3,4,5,66]
# a.insert(where,what)
a.insert(1,55)
print(a)

a = [10,30,20,40,55]
b = [100,2000,32423, 6]


# a.extend((b))
# print(a)

# How to replace a value in list 
a[1] = 45
print(a)

# How to delete 
print("+++++++++++++++++")
a = [10,30,20,10,40,55]
b = [100,2000,32423, 6]

# a.remove(what)
# a.remove(10)
# print(a)

# how to use pop function 
a.pop()
print(a)

# del function 
print("+++++++++++++++++++del ++++++++++++++")
# where is the thing need to be removed
a = [10,30,20,10,40,55]
del a[1]
print(a)

# clear 
print("++++++++++++++++clear+++++++++++++")
a = [10,30,20,10,40,55]

a.clear()
print(a)

# How to interate on a list 
a = [10,30,20,10,40,55]
# print(a[0])
# print(a[1])
# print(a[2])
# print(a[3])
# print(a[4])
# print(a[5])
print("++++++++++++++++++For Loop +++++++++++++++++")
for age in a:
    print(age)

print("+++++++++++++++++++Nested Loops+++++++++++++")

a = [[1,2,3,4,5],["Ram","Golu","bablu"],[1.2,1.4,1.6]]
print("first list inside a")
print(a[0][0])
print(a[0][1])
print(a[0][2])
print(a[0][3])
print(a[0][4])

print("+++++++++++Second List +++++++++++++++++")
print(a[1][0])
print(a[1][1])
print(a[1][2])


print("++++++++++++++++Third Nested List +++++++++++++++++")
# print(a[1])
# print(a[2])
print(a[2][0])
print(a[2][1])
print(a[2][2])


print("Printing details using tested for loop")

for values in a:
    # print(value)
    print('now printing next list ')
    for value in values:
        print(value)
