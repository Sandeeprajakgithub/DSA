print("ram")

# Integer
a = 5
print(type(a))


# String
b = "cloudsreadda"
print(type(b))

#float 
c = 1.4
print(type(c))

# There is no concept of character in python





